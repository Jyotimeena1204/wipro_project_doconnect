package com.doconnect.admin.entity;
public enum QuestionStatus { PENDING, APPROVED, REJECTED }

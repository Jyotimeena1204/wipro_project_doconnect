package com.doconnect.admin.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "questions")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Question {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false) private String title;
    @Column(columnDefinition = "TEXT") private String body;
    private String tags;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id") private User author;
    @Enumerated(EnumType.STRING) private QuestionStatus status;
    private boolean closed;
    @Column(name = "created_at") private LocalDateTime createdAt;
}

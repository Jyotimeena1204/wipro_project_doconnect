package com.doconnect.admin.entity;
public enum AnswerStatus { PENDING, APPROVED, REJECTED }

package com.doconnect.admin.service;

import com.doconnect.admin.dto.*;
import com.doconnect.admin.entity.*;
import com.doconnect.admin.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminService {
    private final UserRepository userRepository;
    private final QuestionRepository questionRepository;
    private final AnswerRepository answerRepository;

    public DashboardStats getDashboardStats() {
        return DashboardStats.builder()
                .totalUsers(userRepository.count())
                .activeUsers(userRepository.findAll().stream().filter(User::isActive).count())
                .totalQuestions(questionRepository.count())
                .pendingQuestions(questionRepository.countByStatus(QuestionStatus.PENDING))
                .approvedQuestions(questionRepository.countByStatus(QuestionStatus.APPROVED))
                .totalAnswers(answerRepository.count())
                .pendingAnswers(answerRepository.countByStatus(AnswerStatus.PENDING))
                .build();
    }

    // User management
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream().map(this::toUserDto).collect(Collectors.toList());
    }

    public UserDto toggleUserStatus(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        user.setActive(!user.isActive());
        return toUserDto(userRepository.save(user));
    }

    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }

    // Question management
    public List<QuestionDto> getPendingQuestions() {
        return questionRepository.findByStatus(QuestionStatus.PENDING)
                .stream().map(this::toQuestionDto).collect(Collectors.toList());
    }

    public List<QuestionDto> getAllQuestions() {
        return questionRepository.findAll().stream().map(this::toQuestionDto).collect(Collectors.toList());
    }

    public QuestionDto approveQuestion(Long id) {
        Question q = questionRepository.findById(id).orElseThrow();
        q.setStatus(QuestionStatus.APPROVED);
        return toQuestionDto(questionRepository.save(q));
    }

    public QuestionDto rejectQuestion(Long id) {
        Question q = questionRepository.findById(id).orElseThrow();
        q.setStatus(QuestionStatus.REJECTED);
        return toQuestionDto(questionRepository.save(q));
    }

    public QuestionDto closeQuestion(Long id) {
        Question q = questionRepository.findById(id).orElseThrow();
        q.setClosed(true);
        return toQuestionDto(questionRepository.save(q));
    }

    public void deleteQuestion(Long id) {
        questionRepository.deleteById(id);
    }

    // Answer management
    public List<AnswerDto> getPendingAnswers() {
        return answerRepository.findByStatus(AnswerStatus.PENDING)
                .stream().map(this::toAnswerDto).collect(Collectors.toList());
    }

    public List<AnswerDto> getAllAnswers() {
        return answerRepository.findAll().stream().map(this::toAnswerDto).collect(Collectors.toList());
    }

    public AnswerDto approveAnswer(Long id) {
        Answer a = answerRepository.findById(id).orElseThrow();
        a.setStatus(AnswerStatus.APPROVED);
        return toAnswerDto(answerRepository.save(a));
    }

    public AnswerDto rejectAnswer(Long id) {
        Answer a = answerRepository.findById(id).orElseThrow();
        a.setStatus(AnswerStatus.REJECTED);
        return toAnswerDto(answerRepository.save(a));
    }

    public void deleteAnswer(Long id) {
        answerRepository.deleteById(id);
    }

    // Mappers
    private UserDto toUserDto(User u) {
        return UserDto.builder().id(u.getId()).username(u.getUsername()).email(u.getEmail())
                .role(u.getRole().name()).active(u.isActive()).bio(u.getBio()).createdAt(u.getCreatedAt()).build();
    }

    private QuestionDto toQuestionDto(Question q) {
        return QuestionDto.builder().id(q.getId()).title(q.getTitle()).body(q.getBody())
                .tags(q.getTags()).status(q.getStatus().name()).closed(q.isClosed())
                .author(toUserDto(q.getAuthor())).createdAt(q.getCreatedAt()).build();
    }

    private AnswerDto toAnswerDto(Answer a) {
        return AnswerDto.builder().id(a.getId()).content(a.getContent()).status(a.getStatus().name())
                .likeCount(a.getLikeCount()).author(toUserDto(a.getAuthor()))
                .questionId(a.getQuestion().getId()).createdAt(a.getCreatedAt()).build();
    }
}

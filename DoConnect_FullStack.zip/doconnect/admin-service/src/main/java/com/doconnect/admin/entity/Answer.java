package com.doconnect.admin.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "answers")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Answer {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(columnDefinition = "TEXT") private String content;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "question_id") private Question question;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id") private User author;
    @Enumerated(EnumType.STRING) private AnswerStatus status;
    private int likeCount;
    @Column(name = "created_at") private LocalDateTime createdAt;
}

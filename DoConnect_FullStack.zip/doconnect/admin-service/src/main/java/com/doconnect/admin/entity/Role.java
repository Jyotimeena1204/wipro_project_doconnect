package com.doconnect.admin.entity;
public enum Role { USER, ADMIN }

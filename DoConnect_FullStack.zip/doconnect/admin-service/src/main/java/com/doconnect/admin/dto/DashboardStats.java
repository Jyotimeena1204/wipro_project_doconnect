package com.doconnect.admin.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class DashboardStats {
    private long totalUsers;
    private long activeUsers;
    private long totalQuestions;
    private long pendingQuestions;
    private long approvedQuestions;
    private long totalAnswers;
    private long pendingAnswers;
}

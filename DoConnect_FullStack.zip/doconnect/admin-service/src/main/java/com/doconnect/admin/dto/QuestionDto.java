package com.doconnect.admin.dto;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class QuestionDto {
    private Long id;
    private String title;
    private String body;
    private String tags;
    private String status;
    private boolean closed;
    private UserDto author;
    private LocalDateTime createdAt;
}

package com.doconnect.admin.dto;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AnswerDto {
    private Long id;
    private String content;
    private String status;
    private int likeCount;
    private UserDto author;
    private Long questionId;
    private LocalDateTime createdAt;
}

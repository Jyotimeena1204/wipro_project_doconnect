package com.doconnect.admin.repository;
import com.doconnect.admin.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface QuestionRepository extends JpaRepository<Question, Long> {
    List<Question> findByStatus(QuestionStatus status);
    long countByStatus(QuestionStatus status);
}

package com.doconnect.admin.controller;

import com.doconnect.admin.dto.*;
import com.doconnect.admin.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {
    private final AdminService adminService;

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<DashboardStats>> getDashboard() {
        return ResponseEntity.ok(ApiResponse.success(adminService.getDashboardStats()));
    }

    // User endpoints
    @GetMapping("/users")
    public ResponseEntity<ApiResponse<List<UserDto>>> getAllUsers() {
        return ResponseEntity.ok(ApiResponse.success(adminService.getAllUsers()));
    }

    @PutMapping("/users/{id}/toggle-status")
    public ResponseEntity<ApiResponse<UserDto>> toggleUserStatus(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("User status updated", adminService.toggleUserStatus(id)));
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteUser(@PathVariable Long id) {
        adminService.deleteUser(id);
        return ResponseEntity.ok(ApiResponse.success("User deleted", null));
    }

    // Question endpoints
    @GetMapping("/questions")
    public ResponseEntity<ApiResponse<List<QuestionDto>>> getAllQuestions() {
        return ResponseEntity.ok(ApiResponse.success(adminService.getAllQuestions()));
    }

    @GetMapping("/questions/pending")
    public ResponseEntity<ApiResponse<List<QuestionDto>>> getPendingQuestions() {
        return ResponseEntity.ok(ApiResponse.success(adminService.getPendingQuestions()));
    }

    @PutMapping("/questions/{id}/approve")
    public ResponseEntity<ApiResponse<QuestionDto>> approveQuestion(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Question approved", adminService.approveQuestion(id)));
    }

    @PutMapping("/questions/{id}/reject")
    public ResponseEntity<ApiResponse<QuestionDto>> rejectQuestion(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Question rejected", adminService.rejectQuestion(id)));
    }

    @PutMapping("/questions/{id}/close")
    public ResponseEntity<ApiResponse<QuestionDto>> closeQuestion(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Question closed", adminService.closeQuestion(id)));
    }

    @DeleteMapping("/questions/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteQuestion(@PathVariable Long id) {
        adminService.deleteQuestion(id);
        return ResponseEntity.ok(ApiResponse.success("Question deleted", null));
    }

    // Answer endpoints
    @GetMapping("/answers")
    public ResponseEntity<ApiResponse<List<AnswerDto>>> getAllAnswers() {
        return ResponseEntity.ok(ApiResponse.success(adminService.getAllAnswers()));
    }

    @GetMapping("/answers/pending")
    public ResponseEntity<ApiResponse<List<AnswerDto>>> getPendingAnswers() {
        return ResponseEntity.ok(ApiResponse.success(adminService.getPendingAnswers()));
    }

    @PutMapping("/answers/{id}/approve")
    public ResponseEntity<ApiResponse<AnswerDto>> approveAnswer(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Answer approved", adminService.approveAnswer(id)));
    }

    @PutMapping("/answers/{id}/reject")
    public ResponseEntity<ApiResponse<AnswerDto>> rejectAnswer(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Answer rejected", adminService.rejectAnswer(id)));
    }

    @DeleteMapping("/answers/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteAnswer(@PathVariable Long id) {
        adminService.deleteAnswer(id);
        return ResponseEntity.ok(ApiResponse.success("Answer deleted", null));
    }
}

package com.doconnect.admin.repository;
import com.doconnect.admin.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface AnswerRepository extends JpaRepository<Answer, Long> {
    List<Answer> findByStatus(AnswerStatus status);
    long countByStatus(AnswerStatus status);
}

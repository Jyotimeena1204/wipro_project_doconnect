-- DoConnect Database Schema
-- Run this ONCE to set up the database (Spring Boot auto-creates via ddl-auto=update)

CREATE DATABASE IF NOT EXISTS doconnect_auth CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE doconnect_auth;

-- Tables are auto-created by Spring Boot JPA (ddl-auto=update)
-- This script seeds an admin user after tables are created

-- After running the app once, insert an admin user:
-- (password = 'admin123' bcrypt hash)
INSERT IGNORE INTO users (username, email, password, role, active, created_at, updated_at)
VALUES (
  'admin',
  'admin@doconnect.com',
  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhy',
  'ADMIN',
  1,
  NOW(),
  NOW()
);

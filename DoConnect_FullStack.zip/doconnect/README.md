# DoConnect - Full Stack Discussion Platform

A community Q&A and discussion platform built with React + Spring Boot Microservices.

## Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│  React Frontend │────▶│  Auth Service    │────▶│   MySQL DB       │
│  (Port 3000)    │     │  (Port 8081)     │     │  doconnect_auth  │
│                 │     └──────────────────┘     └──────────────────┘
│                 │────▶┌──────────────────┐              ▲
│                 │     │  Admin Service   │──────────────┘
│                 │     │  (Port 8082)     │
└─────────────────┘     └──────────────────┘
         │
         │              ┌──────────────────┐
         └─────────────▶│  Eureka Server   │
                        │  (Port 8761)     │
                        └──────────────────┘
```

## Services

| Service        | Port | Description                                    |
|----------------|------|------------------------------------------------|
| Eureka Service | 8761 | Service discovery & registry                   |
| Auth Service   | 8081 | Auth, users, questions, answers, chat, notifs  |
| Admin Service  | 8082 | Admin panel — moderation, approval workflows   |
| React Frontend | 3000 | Full UI — user + admin interfaces              |

## Quick Start

### Prerequisites
- Java 17+
- Node.js 18+
- MySQL 8+
- Maven 3.8+

### 1. Database Setup
```sql
CREATE DATABASE doconnect_auth;
```
Run schema.sql to seed the admin user.

### 2. Start Eureka Server
```bash
cd eureka-service
mvn spring-boot:run
# Open: http://localhost:8761
```

### 3. Start Auth Service
```bash
cd auth-service
# Edit src/main/resources/application.yml — set your MySQL password
mvn spring-boot:run
```

### 4. Start Admin Service
```bash
cd admin-service
# Edit src/main/resources/application.yml — set your MySQL password
mvn spring-boot:run
```

### 5. Start React Frontend
```bash
cd frontend
npm install
npm start
# Open: http://localhost:3000
```

## Default Admin Credentials
- **Email:** admin@doconnect.com
- **Password:** admin123

## API Endpoints

### Auth Service (8081)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /api/auth/register | No | Register user |
| POST | /api/auth/login | No | Login |
| GET | /api/users/me | Yes | Get own profile |
| PUT | /api/users/me | Yes | Update profile |
| GET | /api/questions/approved | No | List approved questions |
| GET | /api/questions/search?keyword= | No | Search questions |
| GET | /api/questions/{id} | Yes | Question detail |
| POST | /api/questions | Yes | Create question |
| POST | /api/questions/{id}/answers | Yes | Post answer |
| POST | /api/questions/answers/{id}/like | Yes | Like answer |
| POST | /api/questions/answers/{id}/comments | Yes | Add comment |
| GET | /api/messages/conversation/{userId} | Yes | Get conversation |
| POST | /api/messages/{receiverId} | Yes | Send message |
| GET | /api/notifications | Yes | Get notifications |
| PUT | /api/notifications/mark-read | Yes | Mark all read |

### Admin Service (8082) — ADMIN role required
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/admin/dashboard | Dashboard stats |
| GET | /api/admin/users | All users |
| PUT | /api/admin/users/{id}/toggle-status | Activate/deactivate |
| DELETE | /api/admin/users/{id} | Delete user |
| GET | /api/admin/questions | All questions |
| PUT | /api/admin/questions/{id}/approve | Approve question |
| PUT | /api/admin/questions/{id}/reject | Reject question |
| PUT | /api/admin/questions/{id}/close | Close question |
| DELETE | /api/admin/questions/{id} | Delete question |
| GET | /api/admin/answers | All answers |
| PUT | /api/admin/answers/{id}/approve | Approve answer |
| PUT | /api/admin/answers/{id}/reject | Reject answer |
| DELETE | /api/admin/answers/{id} | Delete answer |

## Tech Stack
- **Frontend:** React 18, React Router 6, Axios, react-hot-toast
- **Backend:** Spring Boot 3.2, Spring Security + JWT, Spring Data JPA
- **Service Discovery:** Netflix Eureka
- **Database:** MySQL 8
- **Build:** Maven

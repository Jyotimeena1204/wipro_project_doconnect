import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { questionService } from '../../services/api';
import toast from 'react-hot-toast';
import './UserPages.css';

export default function AskQuestionPage() {
  const [form, setForm] = useState({ title: '', body: '', tags: '' });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await questionService.create(form);
      toast.success('Question submitted! It will appear after admin approval.');
      navigate('/');
    } catch (err) {
      toast.error(err.message || 'Failed to submit question');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Ask a Question</h1>
          <p className="page-subtitle">Share your question with the community</p>
        </div>
      </div>

      <div className="form-card">
        <form onSubmit={handleSubmit} className="ask-form">
          <div className="field-group">
            <label className="field-label">Question Title <span className="required">*</span></label>
            <input
              type="text" required
              className="field-input"
              placeholder="e.g. How do I implement JWT authentication in Spring Boot?"
              value={form.title}
              onChange={e => setForm({...form, title: e.target.value})}
            />
            <span className="field-hint">Be specific and clear</span>
          </div>

          <div className="field-group">
            <label className="field-label">Details <span className="required">*</span></label>
            <textarea
              required rows={10}
              className="field-textarea"
              placeholder="Describe your question in detail. Include what you've tried, any error messages, and what you expect to happen..."
              value={form.body}
              onChange={e => setForm({...form, body: e.target.value})}
            />
          </div>

          <div className="field-group">
            <label className="field-label">Tags <span className="optional">(optional)</span></label>
            <input
              type="text"
              className="field-input"
              placeholder="java, spring-boot, react (comma separated)"
              value={form.tags}
              onChange={e => setForm({...form, tags: e.target.value})}
            />
            <span className="field-hint">Add up to 5 relevant tags to help others find your question</span>
          </div>

          <div className="form-actions">
            <button type="button" className="btn-ghost" onClick={() => navigate('/')}>Cancel</button>
            <button type="submit" className="btn-accent" disabled={loading}>
              {loading ? <><span className="btn-spinner-sm" /> Submitting...</> : 'Submit Question'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

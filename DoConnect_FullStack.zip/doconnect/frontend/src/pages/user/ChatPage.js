import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { messageService, userService } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';
import './UserPages.css';

export default function ChatPage() {
  const { userId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);
  const [chatUser, setChatUser] = useState(null);
  const [newMsg, setNewMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchId, setSearchId] = useState('');
  const bottomRef = useRef(null);

  useEffect(() => {
    if (userId) {
      setLoading(true);
      Promise.all([
        userService.getById(userId),
        messageService.getConversation(userId)
      ])
        .then(([userRes, msgRes]) => {
          setChatUser(userRes.data);
          setMessages(msgRes.data || []);
        })
        .catch(() => toast.error('Failed to load chat'))
        .finally(() => setLoading(false));
    }
  }, [userId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!newMsg.trim() || !userId) return;
    try {
      const res = await messageService.send(userId, newMsg.trim());
      setMessages(prev => [...prev, res.data]);
      setNewMsg('');
    } catch {
      toast.error('Failed to send message');
    }
  };

  const handleStartChat = () => {
    if (!searchId.trim()) return;
    navigate(`/chat/${searchId.trim()}`);
  };

  const myId = user?.id || user?.userId || parseInt(localStorage.getItem('userId'));

  return (
    <div className="page fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Messages</h1>
          <p className="page-subtitle">Chat with community members</p>
        </div>
      </div>

      <div className="chat-layout">
        <div className="chat-sidebar">
          <div className="chat-search">
            <input
              className="field-input-sm"
              placeholder="Enter user ID to chat..."
              value={searchId}
              onChange={e => setSearchId(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleStartChat()}
            />
            <button className="btn-sm-accent" onClick={handleStartChat}>Go</button>
          </div>
          {chatUser && (
            <div className="chat-contact active">
              <div className="contact-avatar">{chatUser.username?.[0]?.toUpperCase()}</div>
              <div className="contact-info">
                <div className="contact-name">{chatUser.username}</div>
                <div className="contact-last">{messages[messages.length - 1]?.content?.substring(0, 30) || 'No messages yet'}</div>
              </div>
            </div>
          )}
          {!chatUser && (
            <div className="chat-empty-sidebar">
              <p>Enter a user ID above to start a conversation</p>
            </div>
          )}
        </div>

        <div className="chat-main">
          {!userId ? (
            <div className="chat-welcome">
              <div className="chat-welcome-icon">◎</div>
              <h3>Select a conversation</h3>
              <p>Enter a user ID on the left to start chatting</p>
            </div>
          ) : loading ? (
            <div className="chat-loading"><div className="spinner" /></div>
          ) : (
            <>
              <div className="chat-header">
                <div className="contact-avatar">{chatUser?.username?.[0]?.toUpperCase()}</div>
                <div>
                  <div className="chat-username">{chatUser?.username}</div>
                  <div className="chat-status">ID: {userId}</div>
                </div>
              </div>

              <div className="chat-messages">
                {messages.length === 0 && (
                  <div className="no-messages">Start the conversation!</div>
                )}
                {messages.map((msg, i) => {
                  const isMe = msg.sender?.id === myId;
                  return (
                    <div key={msg.id || i} className={`message-bubble ${isMe ? 'mine' : 'theirs'}`}>
                      <div className="bubble-text">{msg.content}</div>
                      <div className="bubble-time">
                        {msg.createdAt ? new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                      </div>
                    </div>
                  );
                })}
                <div ref={bottomRef} />
              </div>

              <form className="chat-input-row" onSubmit={handleSend}>
                <input
                  className="chat-input"
                  placeholder="Type a message..."
                  value={newMsg}
                  onChange={e => setNewMsg(e.target.value)}
                />
                <button type="submit" className="btn-send" disabled={!newMsg.trim()}>
                  ➤
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { questionService } from '../../services/api';
import toast from 'react-hot-toast';
import './UserPages.css';

export default function QuestionListPage() {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    questionService.getApproved()
      .then(res => setQuestions(res.data || []))
      .catch(() => toast.error('Failed to load questions'))
      .finally(() => setLoading(false));
  }, []);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!search.trim()) {
      questionService.getApproved().then(res => setQuestions(res.data || []));
      return;
    }
    setSearching(true);
    try {
      const res = await questionService.search(search.trim());
      setQuestions(res.data || []);
    } catch {
      toast.error('Search failed');
    } finally {
      setSearching(false);
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const diff = (Date.now() - d.getTime()) / 1000;
    if (diff < 60) return 'just now';
    if (diff < 3600) return `${Math.floor(diff/60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
    return `${Math.floor(diff/86400)}d ago`;
  };

  return (
    <div className="page fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Questions</h1>
          <p className="page-subtitle">{questions.length} discussions in the community</p>
        </div>
        <Link to="/ask" className="btn-accent">
          <span>+</span> Ask Question
        </Link>
      </div>

      <form onSubmit={handleSearch} className="search-bar">
        <div className="search-input-wrap">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            className="search-input"
            placeholder="Search questions, tags, keywords..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          {search && (
            <button type="button" className="search-clear" onClick={() => {
              setSearch('');
              questionService.getApproved().then(res => setQuestions(res.data || []));
            }}>✕</button>
          )}
        </div>
        <button type="submit" className="btn-search" disabled={searching}>
          {searching ? <span className="btn-spinner-sm" /> : 'Search'}
        </button>
      </form>

      {loading ? (
        <div className="skeleton-list">
          {[1,2,3,4,5].map(i => <div key={i} className="skeleton-card" />)}
        </div>
      ) : questions.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">◇</div>
          <h3>No questions found</h3>
          <p>Be the first to ask something!</p>
          <Link to="/ask" className="btn-accent">Ask a Question</Link>
        </div>
      ) : (
        <div className="questions-list">
          {questions.map((q, i) => (
            <Link to={`/questions/${q.id}`} key={q.id}
              className="question-card fade-in"
              style={{ animationDelay: `${i * 0.05}s` }}>
              <div className="question-meta-left">
                <div className="answer-count">
                  <span className="count-num">{q.answers?.length || 0}</span>
                  <span className="count-label">answers</span>
                </div>
              </div>
              <div className="question-body">
                <h3 className="question-title">{q.title}</h3>
                <p className="question-excerpt">{q.body?.substring(0, 160)}{q.body?.length > 160 ? '...' : ''}</p>
                <div className="question-footer">
                  <div className="tags">
                    {q.tags?.split(',').filter(Boolean).map(tag => (
                      <span key={tag} className="tag">{tag.trim()}</span>
                    ))}
                  </div>
                  <div className="question-info">
                    <span className="author-chip">
                      <span className="author-avatar">{q.author?.username?.[0]?.toUpperCase()}</span>
                      {q.author?.username}
                    </span>
                    <span className="dot">·</span>
                    <span className="time">{formatDate(q.createdAt)}</span>
                    {q.closed && <span className="closed-badge">Closed</span>}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

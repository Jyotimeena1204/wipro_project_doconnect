import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { questionService } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';
import './UserPages.css';

export default function QuestionDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const [question, setQuestion] = useState(null);
  const [loading, setLoading] = useState(true);
  const [answerText, setAnswerText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [commentTexts, setCommentTexts] = useState({});
  const [showCommentFor, setShowCommentFor] = useState(null);

  useEffect(() => {
    questionService.getById(id)
      .then(res => setQuestion(res.data))
      .catch(() => toast.error('Failed to load question'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleAnswer = async (e) => {
    e.preventDefault();
    if (!answerText.trim()) return;
    setSubmitting(true);
    try {
      await questionService.addAnswer(id, { content: answerText });
      toast.success('Answer submitted for review!');
      setAnswerText('');
    } catch (err) {
      toast.error(err.message || 'Failed to submit');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLike = async (answerId) => {
    try {
      const res = await questionService.likeAnswer(answerId);
      setQuestion(prev => ({
        ...prev,
        answers: prev.answers.map(a => a.id === answerId ? { ...a, likeCount: res.data.likeCount } : a)
      }));
    } catch {
      toast.error('Failed to like');
    }
  };

  const handleComment = async (answerId) => {
    const content = commentTexts[answerId];
    if (!content?.trim()) return;
    try {
      const res = await questionService.addComment(answerId, content);
      setQuestion(prev => ({
        ...prev,
        answers: prev.answers.map(a => a.id === answerId
          ? { ...a, comments: [...(a.comments || []), res.data] }
          : a)
      }));
      setCommentTexts(prev => ({ ...prev, [answerId]: '' }));
      setShowCommentFor(null);
      toast.success('Comment added!');
    } catch {
      toast.error('Failed to add comment');
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  if (loading) return <div className="page"><div className="loading-page"><div className="spinner" /></div></div>;
  if (!question) return <div className="page"><div className="empty-state"><h3>Question not found</h3><Link to="/" className="btn-accent">Back to Feed</Link></div></div>;

  return (
    <div className="page fade-in">
      <Link to="/" className="back-link">← Back to Questions</Link>

      <div className="question-detail-card">
        <div className="qd-header">
          <div className="tags">{question.tags?.split(',').filter(Boolean).map(t => <span key={t} className="tag">{t.trim()}</span>)}</div>
          <div className="qd-meta">
            <span className="author-chip">
              <span className="author-avatar">{question.author?.username?.[0]?.toUpperCase()}</span>
              {question.author?.username}
            </span>
            <span className="dot">·</span>
            <span className="time">{formatDate(question.createdAt)}</span>
            {question.closed && <span className="closed-badge">Closed</span>}
          </div>
        </div>
        <h1 className="qd-title">{question.title}</h1>
        <div className="qd-body">{question.body}</div>
      </div>

      <div className="answers-section">
        <h2 className="section-title">
          <span className="section-icon">◆</span>
          {question.answers?.length || 0} Answer{question.answers?.length !== 1 ? 's' : ''}
        </h2>

        {question.answers?.length === 0 && (
          <div className="empty-state small">
            <p>No approved answers yet. Be the first!</p>
          </div>
        )}

        {question.answers?.map((answer, i) => (
          <div key={answer.id} className="answer-card fade-in" style={{ animationDelay: `${i * 0.07}s` }}>
            <div className="answer-vote">
              <button className="like-btn" onClick={() => handleLike(answer.id)}>▲</button>
              <span className="like-count">{answer.likeCount}</span>
            </div>
            <div className="answer-body">
              <div className="answer-content">{answer.content}</div>
              <div className="answer-footer">
                <div className="answer-meta">
                  <span className="author-chip">
                    <span className="author-avatar">{answer.author?.username?.[0]?.toUpperCase()}</span>
                    {answer.author?.username}
                  </span>
                  <span className="dot">·</span>
                  <span className="time">{formatDate(answer.createdAt)}</span>
                </div>
                <button className="comment-toggle-btn"
                  onClick={() => setShowCommentFor(showCommentFor === answer.id ? null : answer.id)}>
                  💬 {answer.comments?.length || 0} Comments
                </button>
              </div>

              {answer.comments?.length > 0 && (
                <div className="comments-list">
                  {answer.comments.map(c => (
                    <div key={c.id} className="comment">
                      <span className="comment-author">{c.author?.username}</span>
                      <span className="comment-text">{c.content}</span>
                    </div>
                  ))}
                </div>
              )}

              {showCommentFor === answer.id && (
                <div className="comment-input-row">
                  <input
                    className="field-input-sm"
                    placeholder="Add a comment..."
                    value={commentTexts[answer.id] || ''}
                    onChange={e => setCommentTexts(prev => ({ ...prev, [answer.id]: e.target.value }))}
                    onKeyDown={e => e.key === 'Enter' && handleComment(answer.id)}
                  />
                  <button className="btn-sm-accent" onClick={() => handleComment(answer.id)}>Post</button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {!question.closed && (
        <div className="answer-form-section">
          <h2 className="section-title"><span className="section-icon">✏</span> Your Answer</h2>
          <form onSubmit={handleAnswer}>
            <textarea
              className="answer-textarea"
              placeholder="Share your knowledge... Be detailed and helpful!"
              value={answerText}
              onChange={e => setAnswerText(e.target.value)}
              rows={6}
              required
            />
            <div className="answer-form-footer">
              <span className="answer-hint">Your answer will be reviewed before publishing</span>
              <button type="submit" className="btn-accent" disabled={submitting}>
                {submitting ? <span className="btn-spinner-sm" /> : 'Post Answer'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

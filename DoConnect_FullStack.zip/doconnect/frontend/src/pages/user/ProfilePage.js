import React, { useState, useEffect } from 'react';
import { questionService, notificationService, userService } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';
import './UserPages.css';

export default function ProfilePage() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [myQuestions, setMyQuestions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [activeTab, setActiveTab] = useState('questions');
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ bio: '' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      userService.getMe(),
      questionService.getMy(),
      notificationService.getAll()
    ])
      .then(([profileRes, qRes, nRes]) => {
        setProfile(profileRes.data);
        setEditForm({ bio: profileRes.data.bio || '' });
        setMyQuestions(qRes.data || []);
        setNotifications(nRes.data || []);
      })
      .catch(() => toast.error('Failed to load profile'))
      .finally(() => setLoading(false));
  }, []);

  const handleMarkRead = async () => {
    try {
      await notificationService.markAllRead();
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      toast.success('All marked as read');
    } catch {
      toast.error('Failed to mark as read');
    }
  };

  const handleSaveProfile = async () => {
    try {
      const res = await userService.updateProfile(editForm);
      setProfile(res.data);
      setEditing(false);
      toast.success('Profile updated!');
    } catch {
      toast.error('Failed to update profile');
    }
  };

  const formatDate = (d) => d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '';
  const getStatusColor = (s) => ({ APPROVED: 'success', REJECTED: 'danger', PENDING: 'warning' }[s] || 'muted');

  if (loading) return <div className="page"><div className="loading-page"><div className="spinner" /></div></div>;

  return (
    <div className="page fade-in">
      <div className="profile-hero">
        <div className="profile-avatar-large">{profile?.username?.[0]?.toUpperCase()}</div>
        <div className="profile-info">
          <h1 className="profile-name">{profile?.username}</h1>
          <p className="profile-email">{profile?.email}</p>
          {editing ? (
            <div className="edit-bio-row">
              <input className="field-input-sm" value={editForm.bio}
                onChange={e => setEditForm({ bio: e.target.value })}
                placeholder="Tell us about yourself..." />
              <button className="btn-sm-accent" onClick={handleSaveProfile}>Save</button>
              <button className="btn-sm-ghost" onClick={() => setEditing(false)}>Cancel</button>
            </div>
          ) : (
            <p className="profile-bio">{profile?.bio || 'No bio yet'}</p>
          )}
        </div>
        <div className="profile-actions">
          <div className="profile-stat">
            <span className="stat-num">{myQuestions.length}</span>
            <span className="stat-label">Questions</span>
          </div>
          <div className="profile-stat">
            <span className="stat-num">{notifications.filter(n => !n.read).length}</span>
            <span className="stat-label">Unread</span>
          </div>
          <button className="btn-ghost" onClick={() => setEditing(!editing)}>✏ Edit Profile</button>
        </div>
      </div>

      <div className="profile-tabs">
        {['questions', 'notifications'].map(tab => (
          <button key={tab} className={`tab-btn ${activeTab === tab ? 'active' : ''}`}
            onClick={() => setActiveTab(tab)}>
            {tab === 'questions' ? `My Questions (${myQuestions.length})` : `Notifications (${notifications.filter(n => !n.read).length} unread)`}
          </button>
        ))}
      </div>

      {activeTab === 'questions' && (
        <div className="tab-content">
          {myQuestions.length === 0 ? (
            <div className="empty-state small"><p>You haven't asked any questions yet.</p></div>
          ) : (
            myQuestions.map(q => (
              <div key={q.id} className="profile-question-card">
                <div className="pq-header">
                  <h3 className="pq-title">{q.title}</h3>
                  <span className={`status-pill ${getStatusColor(q.status)}`}>{q.status}</span>
                </div>
                <p className="pq-excerpt">{q.body?.substring(0, 120)}...</p>
                <div className="pq-meta">
                  <span className="time">{formatDate(q.createdAt)}</span>
                  {q.closed && <span className="closed-badge">Closed</span>}
                  <div className="tags">{q.tags?.split(',').filter(Boolean).map(t => <span key={t} className="tag">{t.trim()}</span>)}</div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'notifications' && (
        <div className="tab-content">
          {notifications.length > 0 && (
            <div className="notif-header">
              <button className="btn-ghost-sm" onClick={handleMarkRead}>Mark all as read</button>
            </div>
          )}
          {notifications.length === 0 ? (
            <div className="empty-state small"><p>No notifications yet.</p></div>
          ) : (
            notifications.map(n => (
              <div key={n.id} className={`notif-card ${!n.read ? 'unread' : ''}`}>
                <div className="notif-dot" />
                <div className="notif-content">
                  <p className="notif-message">{n.message}</p>
                  <span className="time">{formatDate(n.createdAt)}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

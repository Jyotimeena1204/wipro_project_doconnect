import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { authService } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';
import './Auth.css';

export default function RegisterPage() {
  const [form, setForm] = useState({ username: '', email: '', password: '', bio: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authService.register(form);
      login(res.data);
      toast.success('Account created! Welcome to DoConnect!');
      navigate('/');
    } catch (err) {
      toast.error(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-bg">
        <div className="auth-orb orb1" />
        <div className="auth-orb orb2" />
        <div className="auth-grid" />
      </div>
      <div className="auth-card fade-in">
        <div className="auth-header">
          <div className="auth-logo">⬡</div>
          <h1 className="auth-title">Join DoConnect</h1>
          <p className="auth-subtitle">Create your account</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="field-group">
            <label className="field-label">Username</label>
            <input type="text" required className="field-input" placeholder="cooldev123"
              value={form.username} onChange={e => setForm({...form, username: e.target.value})} />
          </div>
          <div className="field-group">
            <label className="field-label">Email</label>
            <input type="email" required className="field-input" placeholder="you@example.com"
              value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
          </div>
          <div className="field-group">
            <label className="field-label">Password</label>
            <input type="password" required minLength={6} className="field-input" placeholder="Min 6 characters"
              value={form.password} onChange={e => setForm({...form, password: e.target.value})} />
          </div>
          <div className="field-group">
            <label className="field-label">Bio <span className="optional">(optional)</span></label>
            <input type="text" className="field-input" placeholder="Tell us about yourself..."
              value={form.bio} onChange={e => setForm({...form, bio: e.target.value})} />
          </div>
          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? <span className="btn-spinner" /> : 'Create Account'}
          </button>
        </form>

        <p className="auth-footer">
          Already have an account? <Link to="/login" className="auth-link">Sign in</Link>
        </p>
      </div>
    </div>
  );
}

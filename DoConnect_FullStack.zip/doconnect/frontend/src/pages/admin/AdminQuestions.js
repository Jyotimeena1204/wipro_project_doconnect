import React, { useState, useEffect } from 'react';
import { adminService } from '../../services/api';
import toast from 'react-hot-toast';
import './AdminPages.css';

export default function AdminQuestions() {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('ALL');

  useEffect(() => {
    adminService.getAllQuestions()
      .then(res => setQuestions(res.data || []))
      .catch(() => toast.error('Failed to load questions'))
      .finally(() => setLoading(false));
  }, []);

  const doAction = async (action, id, label) => {
    try {
      const res = await action(id);
      setQuestions(prev => prev.map(q => q.id === id ? res.data : q));
      toast.success(label);
    } catch { toast.error(`Failed: ${label}`); }
  };

  const doDelete = async (id) => {
    if (!window.confirm('Delete this question?')) return;
    try {
      await adminService.deleteQuestion(id);
      setQuestions(prev => prev.filter(q => q.id !== id));
      toast.success('Question deleted');
    } catch { toast.error('Failed to delete'); }
  };

  const filtered = filter === 'ALL' ? questions : questions.filter(q => q.status === filter);
  const counts = { ALL: questions.length, PENDING: questions.filter(q => q.status === 'PENDING').length, APPROVED: questions.filter(q => q.status === 'APPROVED').length, REJECTED: questions.filter(q => q.status === 'REJECTED').length };

  if (loading) return <div className="admin-loading"><div className="spinner" /></div>;

  return (
    <div className="admin-page fade-in">
      <div className="filter-tabs">
        {Object.entries(counts).map(([key, count]) => (
          <button key={key} className={`filter-tab ${filter === key ? 'active' : ''}`} onClick={() => setFilter(key)}>
            {key} <span className="filter-count">{count}</span>
          </button>
        ))}
      </div>

      <div className="content-list">
        {filtered.length === 0 ? (
          <div className="table-empty">No questions in this category</div>
        ) : (
          filtered.map(q => (
            <div key={q.id} className="content-card">
              <div className="content-card-header">
                <div className="content-card-title">{q.title}</div>
                <div className="content-card-badges">
                  <span className={`status-pill ${q.status === 'APPROVED' ? 'success' : q.status === 'REJECTED' ? 'danger' : 'warning'}`}>{q.status}</span>
                  {q.closed && <span className="status-pill danger">Closed</span>}
                </div>
              </div>
              <p className="content-card-body">{q.body?.substring(0, 150)}...</p>
              <div className="content-card-footer">
                <div className="content-meta">
                  <span className="author-chip">
                    <span className="author-avatar-sm">{q.author?.username?.[0]?.toUpperCase()}</span>
                    {q.author?.username}
                  </span>
                  {q.tags && <div className="tags">{q.tags.split(',').filter(Boolean).map(t => <span key={t} className="tag">{t.trim()}</span>)}</div>}
                  <span className="text-muted-sm">#{q.id}</span>
                </div>
                <div className="table-actions">
                  {q.status === 'PENDING' && <>
                    <button className="table-btn success" onClick={() => doAction(adminService.approveQuestion, q.id, 'Approved!')}>Approve</button>
                    <button className="table-btn warn" onClick={() => doAction(adminService.rejectQuestion, q.id, 'Rejected')}>Reject</button>
                  </>}
                  {q.status === 'APPROVED' && !q.closed && (
                    <button className="table-btn warn" onClick={() => doAction(adminService.closeQuestion, q.id, 'Question closed')}>Close</button>
                  )}
                  <button className="table-btn danger" onClick={() => doDelete(q.id)}>Delete</button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

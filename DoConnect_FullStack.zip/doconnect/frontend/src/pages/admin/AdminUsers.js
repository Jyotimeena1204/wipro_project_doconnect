import React, { useState, useEffect } from 'react';
import { adminService } from '../../services/api';
import toast from 'react-hot-toast';
import './AdminPages.css';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    adminService.getAllUsers()
      .then(res => setUsers(res.data || []))
      .catch(() => toast.error('Failed to load users'))
      .finally(() => setLoading(false));
  }, []);

  const handleToggle = async (id) => {
    try {
      const res = await adminService.toggleUserStatus(id);
      setUsers(prev => prev.map(u => u.id === id ? res.data : u));
      toast.success('User status updated');
    } catch { toast.error('Failed to update status'); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this user? This cannot be undone.')) return;
    try {
      await adminService.deleteUser(id);
      setUsers(prev => prev.filter(u => u.id !== id));
      toast.success('User deleted');
    } catch { toast.error('Failed to delete user'); }
  };

  const filtered = users.filter(u =>
    u.username?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <div className="admin-loading"><div className="spinner" /></div>;

  return (
    <div className="admin-page fade-in">
      <div className="admin-page-header">
        <div className="admin-page-stats">
          <span className="admin-stat-badge total">{users.length} Total</span>
          <span className="admin-stat-badge active">{users.filter(u => u.active).length} Active</span>
          <span className="admin-stat-badge inactive">{users.filter(u => !u.active).length} Inactive</span>
        </div>
        <input
          className="admin-search"
          placeholder="Search users..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="data-table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>User</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Joined</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(u => (
              <tr key={u.id} className={!u.active ? 'row-inactive' : ''}>
                <td>
                  <div className="user-cell">
                    <div className="table-avatar">{u.username?.[0]?.toUpperCase()}</div>
                    <div>
                      <div className="user-name">{u.username}</div>
                      <div className="user-id">#{u.id}</div>
                    </div>
                  </div>
                </td>
                <td className="text-muted">{u.email}</td>
                <td>
                  <span className={`role-badge ${u.role === 'ADMIN' ? 'admin' : 'user'}`}>{u.role}</span>
                </td>
                <td>
                  <span className={`status-dot ${u.active ? 'active' : 'inactive'}`}>
                    {u.active ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="text-muted">
                  {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '—'}
                </td>
                <td>
                  <div className="table-actions">
                    <button
                      className={`table-btn ${u.active ? 'warn' : 'success'}`}
                      onClick={() => handleToggle(u.id)}
                    >
                      {u.active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button className="table-btn danger" onClick={() => handleDelete(u.id)}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="table-empty">No users found</div>}
      </div>
    </div>
  );
}

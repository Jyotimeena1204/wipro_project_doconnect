import React, { useState, useEffect } from 'react';
import { adminService } from '../../services/api';
import toast from 'react-hot-toast';
import './AdminPages.css';

export default function AdminAnswers() {
  const [answers, setAnswers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('ALL');

  useEffect(() => {
    adminService.getAllAnswers ? adminService.getAllAnswers()
      .then(res => setAnswers(res.data || []))
      .catch(() => toast.error('Failed to load answers'))
      .finally(() => setLoading(false))
    : adminService.getPendingAnswers()
      .then(res => setAnswers(res.data || []))
      .catch(() => toast.error('Failed to load answers'))
      .finally(() => setLoading(false));
  }, []);

  const doAction = async (action, id, label) => {
    try {
      const res = await action(id);
      setAnswers(prev => prev.map(a => a.id === id ? res.data : a));
      toast.success(label);
    } catch { toast.error(`Failed: ${label}`); }
  };

  const doDelete = async (id) => {
    if (!window.confirm('Delete this answer?')) return;
    try {
      await adminService.deleteAnswer(id);
      setAnswers(prev => prev.filter(a => a.id !== id));
      toast.success('Answer deleted');
    } catch { toast.error('Failed to delete'); }
  };

  const filtered = filter === 'ALL' ? answers : answers.filter(a => a.status === filter);
  const counts = { ALL: answers.length, PENDING: answers.filter(a => a.status === 'PENDING').length, APPROVED: answers.filter(a => a.status === 'APPROVED').length, REJECTED: answers.filter(a => a.status === 'REJECTED').length };

  if (loading) return <div className="admin-loading"><div className="spinner" /></div>;

  return (
    <div className="admin-page fade-in">
      <div className="filter-tabs">
        {Object.entries(counts).map(([key, count]) => (
          <button key={key} className={`filter-tab ${filter === key ? 'active' : ''}`} onClick={() => setFilter(key)}>
            {key} <span className="filter-count">{count}</span>
          </button>
        ))}
      </div>

      <div className="content-list">
        {filtered.length === 0 ? (
          <div className="table-empty">No answers in this category</div>
        ) : (
          filtered.map(a => (
            <div key={a.id} className="content-card">
              <div className="content-card-header">
                <div className="content-card-title">Answer #{a.id} on Question #{a.questionId}</div>
                <span className={`status-pill ${a.status === 'APPROVED' ? 'success' : a.status === 'REJECTED' ? 'danger' : 'warning'}`}>{a.status}</span>
              </div>
              <p className="content-card-body">{a.content?.substring(0, 200)}...</p>
              <div className="content-card-footer">
                <div className="content-meta">
                  <span className="author-chip">
                    <span className="author-avatar-sm">{a.author?.username?.[0]?.toUpperCase()}</span>
                    {a.author?.username}
                  </span>
                  <span className="text-muted-sm">👍 {a.likeCount}</span>
                </div>
                <div className="table-actions">
                  {a.status === 'PENDING' && <>
                    <button className="table-btn success" onClick={() => doAction(adminService.approveAnswer, a.id, 'Approved!')}>Approve</button>
                    <button className="table-btn warn" onClick={() => doAction(adminService.rejectAnswer, a.id, 'Rejected')}>Reject</button>
                  </>}
                  <button className="table-btn danger" onClick={() => doDelete(a.id)}>Delete</button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

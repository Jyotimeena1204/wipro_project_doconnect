import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { adminService } from '../../services/api';
import toast from 'react-hot-toast';
import './AdminPages.css';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [pendingQ, setPendingQ] = useState([]);
  const [pendingA, setPendingA] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      adminService.getDashboard(),
      adminService.getPendingQuestions(),
      adminService.getPendingAnswers()
    ])
      .then(([sRes, qRes, aRes]) => {
        setStats(sRes.data);
        setPendingQ(qRes.data || []);
        setPendingA(aRes.data || []);
      })
      .catch(() => toast.error('Failed to load dashboard'))
      .finally(() => setLoading(false));
  }, []);

  const handleApproveQ = async (id) => {
    try {
      await adminService.approveQuestion(id);
      setPendingQ(prev => prev.filter(q => q.id !== id));
      setStats(prev => prev ? { ...prev, pendingQuestions: prev.pendingQuestions - 1, approvedQuestions: prev.approvedQuestions + 1 } : prev);
      toast.success('Question approved!');
    } catch { toast.error('Failed to approve'); }
  };

  const handleRejectQ = async (id) => {
    try {
      await adminService.rejectQuestion(id);
      setPendingQ(prev => prev.filter(q => q.id !== id));
      setStats(prev => prev ? { ...prev, pendingQuestions: prev.pendingQuestions - 1 } : prev);
      toast.success('Question rejected');
    } catch { toast.error('Failed to reject'); }
  };

  const handleApproveA = async (id) => {
    try {
      await adminService.approveAnswer(id);
      setPendingA(prev => prev.filter(a => a.id !== id));
      setStats(prev => prev ? { ...prev, pendingAnswers: prev.pendingAnswers - 1 } : prev);
      toast.success('Answer approved!');
    } catch { toast.error('Failed to approve'); }
  };

  const handleRejectA = async (id) => {
    try {
      await adminService.rejectAnswer(id);
      setPendingA(prev => prev.filter(a => a.id !== id));
      setStats(prev => prev ? { ...prev, pendingAnswers: prev.pendingAnswers - 1 } : prev);
      toast.success('Answer rejected');
    } catch { toast.error('Failed to reject'); }
  };

  if (loading) return <div className="admin-loading"><div className="spinner" /></div>;

  const statCards = [
    { label: 'Total Users', value: stats?.totalUsers, icon: '◉', color: 'blue', sub: `${stats?.activeUsers} active` },
    { label: 'Total Questions', value: stats?.totalQuestions, icon: '◇', color: 'purple', sub: `${stats?.approvedQuestions} approved` },
    { label: 'Pending Questions', value: stats?.pendingQuestions, icon: '⏳', color: 'orange', sub: 'Awaiting review' },
    { label: 'Pending Answers', value: stats?.pendingAnswers, icon: '◆', color: 'green', sub: 'Awaiting review' },
  ];

  return (
    <div className="admin-page fade-in">
      <div className="stats-grid">
        {statCards.map((s, i) => (
          <div key={i} className={`stat-card color-${s.color}`} style={{ animationDelay: `${i * 0.08}s` }}>
            <div className="stat-card-header">
              <span className="stat-card-icon">{s.icon}</span>
              <span className="stat-card-label">{s.label}</span>
            </div>
            <div className="stat-card-value">{s.value ?? '—'}</div>
            <div className="stat-card-sub">{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="dashboard-grid">
        <div className="dash-panel">
          <div className="panel-header">
            <h2 className="panel-title">
              <span className="panel-icon pending">⏳</span>
              Pending Questions
              {pendingQ.length > 0 && <span className="panel-badge">{pendingQ.length}</span>}
            </h2>
            <Link to="/admin/questions" className="panel-link">View all →</Link>
          </div>
          {pendingQ.length === 0 ? (
            <div className="panel-empty">All caught up! No pending questions.</div>
          ) : (
            <div className="pending-list">
              {pendingQ.slice(0, 5).map(q => (
                <div key={q.id} className="pending-item">
                  <div className="pending-info">
                    <div className="pending-title">{q.title}</div>
                    <div className="pending-meta">by {q.author?.username} · {q.tags}</div>
                  </div>
                  <div className="pending-actions">
                    <button className="action-btn approve" onClick={() => handleApproveQ(q.id)}>✓</button>
                    <button className="action-btn reject" onClick={() => handleRejectQ(q.id)}>✗</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="dash-panel">
          <div className="panel-header">
            <h2 className="panel-title">
              <span className="panel-icon pending">⏳</span>
              Pending Answers
              {pendingA.length > 0 && <span className="panel-badge">{pendingA.length}</span>}
            </h2>
            <Link to="/admin/answers" className="panel-link">View all →</Link>
          </div>
          {pendingA.length === 0 ? (
            <div className="panel-empty">All caught up! No pending answers.</div>
          ) : (
            <div className="pending-list">
              {pendingA.slice(0, 5).map(a => (
                <div key={a.id} className="pending-item">
                  <div className="pending-info">
                    <div className="pending-title">{a.content?.substring(0, 80)}...</div>
                    <div className="pending-meta">by {a.author?.username} · Q#{a.questionId}</div>
                  </div>
                  <div className="pending-actions">
                    <button className="action-btn approve" onClick={() => handleApproveA(a.id)}>✓</button>
                    <button className="action-btn reject" onClick={() => handleRejectA(a.id)}>✗</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

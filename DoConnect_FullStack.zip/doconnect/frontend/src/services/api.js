import axios from 'axios';

const AUTH_BASE = 'http://localhost:8081';
const ADMIN_BASE = 'http://localhost:8082';

const authApi = axios.create({ baseURL: AUTH_BASE });
const adminApi = axios.create({ baseURL: ADMIN_BASE });

const attachToken = (config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
};

authApi.interceptors.request.use(attachToken);
adminApi.interceptors.request.use(attachToken);

const handleResponse = (response) => response.data;
const handleError = (error) => {
  if (error.response?.status === 401) {
    localStorage.clear();
    window.location.href = '/login';
  }
  return Promise.reject(error.response?.data || error);
};

authApi.interceptors.response.use(handleResponse, handleError);
adminApi.interceptors.response.use(handleResponse, handleError);

export const authService = {
  register: (data) => authApi.post('/api/auth/register', data),
  login: (data) => authApi.post('/api/auth/login', data),
};

export const userService = {
  getMe: () => authApi.get('/api/users/me'),
  getById: (id) => authApi.get(`/api/users/${id}`),
  updateProfile: (data) => authApi.put('/api/users/me', data),
};

export const questionService = {
  getApproved: () => authApi.get('/api/questions/approved'),
  search: (keyword) => authApi.get(`/api/questions/search?keyword=${keyword}`),
  getById: (id) => authApi.get(`/api/questions/${id}`),
  getMy: () => authApi.get('/api/questions/my'),
  create: (data) => authApi.post('/api/questions', data),
  addAnswer: (qId, data) => authApi.post(`/api/questions/${qId}/answers`, data),
  likeAnswer: (aId) => authApi.post(`/api/questions/answers/${aId}/like`),
  addComment: (aId, content) => authApi.post(`/api/questions/answers/${aId}/comments`, { content }),
};

export const messageService = {
  send: (receiverId, content) => authApi.post(`/api/messages/${receiverId}`, { content }),
  getConversation: (userId) => authApi.get(`/api/messages/conversation/${userId}`),
};

export const notificationService = {
  getAll: () => authApi.get('/api/notifications'),
  getUnreadCount: () => authApi.get('/api/notifications/unread-count'),
  markAllRead: () => authApi.put('/api/notifications/mark-read'),
};

export const adminService = {
  getDashboard: () => adminApi.get('/api/admin/dashboard'),
  getAllUsers: () => adminApi.get('/api/admin/users'),
  toggleUserStatus: (id) => adminApi.put(`/api/admin/users/${id}/toggle-status`),
  deleteUser: (id) => adminApi.delete(`/api/admin/users/${id}`),
  getAllQuestions: () => adminApi.get('/api/admin/questions'),
  getPendingQuestions: () => adminApi.get('/api/admin/questions/pending'),
  approveQuestion: (id) => adminApi.put(`/api/admin/questions/${id}/approve`),
  rejectQuestion: (id) => adminApi.put(`/api/admin/questions/${id}/reject`),
  closeQuestion: (id) => adminApi.put(`/api/admin/questions/${id}/close`),
  deleteQuestion: (id) => adminApi.delete(`/api/admin/questions/${id}`),
  getPendingAnswers: () => adminApi.get('/api/admin/answers/pending'),
  approveAnswer: (id) => adminApi.put(`/api/admin/answers/${id}/approve`),
  rejectAnswer: (id) => adminApi.put(`/api/admin/answers/${id}/reject`),
  deleteAnswer: (id) => adminApi.delete(`/api/admin/answers/${id}`),
};

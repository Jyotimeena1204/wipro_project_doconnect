import React, { useState, useEffect } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { notificationService } from '../../services/api';
import './Layout.css';

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [unreadCount, setUnreadCount] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    notificationService.getUnreadCount()
      .then(res => setUnreadCount(res.data || 0))
      .catch(() => {});
    const interval = setInterval(() => {
      notificationService.getUnreadCount()
        .then(res => setUnreadCount(res.data || 0))
        .catch(() => {});
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isActive = (path) => location.pathname === path || (path !== '/' && location.pathname.startsWith(path));

  return (
    <div className="layout">
      <nav className="navbar">
        <div className="navbar-inner">
          <Link to="/" className="logo">
            <span className="logo-icon">⬡</span>
            <span className="logo-text">DoConnect</span>
          </Link>

          <div className="nav-links">
            <Link to="/" className={`nav-link ${isActive('/') && location.pathname === '/' ? 'active' : ''}`}>
              <span className="nav-icon">⊞</span> Feed
            </Link>
            <Link to="/ask" className={`nav-link ${isActive('/ask') ? 'active' : ''}`}>
              <span className="nav-icon">＋</span> Ask
            </Link>
            <Link to="/chat" className={`nav-link ${isActive('/chat') ? 'active' : ''}`}>
              <span className="nav-icon">◎</span> Chat
            </Link>
          </div>

          <div className="nav-right">
            <Link to="/profile" className="notification-bell">
              <span>🔔</span>
              {unreadCount > 0 && <span className="badge">{unreadCount}</span>}
            </Link>
            <div className="avatar-menu" onClick={() => setMenuOpen(!menuOpen)}>
              <div className="avatar">{user?.username?.[0]?.toUpperCase()}</div>
              {menuOpen && (
                <div className="dropdown">
                  <div className="dropdown-header">
                    <div className="dropdown-name">{user?.username}</div>
                    <div className="dropdown-email">{user?.email}</div>
                  </div>
                  <Link to="/profile" className="dropdown-item" onClick={() => setMenuOpen(false)}>Profile</Link>
                  <button className="dropdown-item danger" onClick={handleLogout}>Sign Out</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>
      <main className="main-content">
        <Outlet />
      </main>
    </div>
  );
}

import React, { useState } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './AdminLayout.css';

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };
  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/');

  const navItems = [
    { path: '/admin', label: 'Dashboard', icon: '◈', exact: true },
    { path: '/admin/users', label: 'Users', icon: '◉' },
    { path: '/admin/questions', label: 'Questions', icon: '◇' },
    { path: '/admin/answers', label: 'Answers', icon: '◆' },
  ];

  return (
    <div className={`admin-layout ${collapsed ? 'collapsed' : ''}`}>
      <aside className="admin-sidebar">
        <div className="sidebar-header">
          <div className="sidebar-logo">
            <span className="logo-icon">⬡</span>
            {!collapsed && <span className="logo-text">DoConnect</span>}
          </div>
          {!collapsed && <div className="sidebar-badge">Admin</div>}
          <button className="collapse-btn" onClick={() => setCollapsed(!collapsed)}>
            {collapsed ? '›' : '‹'}
          </button>
        </div>

        <nav className="sidebar-nav">
          {navItems.map(item => (
            <Link
              key={item.path}
              to={item.path}
              className={`sidebar-link ${item.exact ? location.pathname === item.path ? 'active' : '' : isActive(item.path) ? 'active' : ''}`}
            >
              <span className="sidebar-icon">{item.icon}</span>
              {!collapsed && <span className="sidebar-label">{item.label}</span>}
            </Link>
          ))}
        </nav>

        <div className="sidebar-footer">
          <Link to="/" className="sidebar-link">
            <span className="sidebar-icon">↗</span>
            {!collapsed && <span className="sidebar-label">User View</span>}
          </Link>
          <button className="sidebar-link danger" onClick={handleLogout}>
            <span className="sidebar-icon">⏻</span>
            {!collapsed && <span className="sidebar-label">Sign Out</span>}
          </button>
        </div>
      </aside>

      <div className="admin-body">
        <header className="admin-topbar">
          <div className="topbar-title">
            {navItems.find(i => i.exact ? location.pathname === i.path : location.pathname.startsWith(i.path))?.label || 'Admin Panel'}
          </div>
          <div className="topbar-user">
            <div className="avatar-sm">{user?.username?.[0]?.toUpperCase()}</div>
            <span className="topbar-username">{user?.username}</span>
          </div>
        </header>
        <main className="admin-main"><Outlet /></main>
      </div>
    </div>
  );
}

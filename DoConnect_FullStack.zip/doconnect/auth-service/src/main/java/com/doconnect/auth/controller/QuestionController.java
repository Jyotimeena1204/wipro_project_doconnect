package com.doconnect.auth.controller;

import com.doconnect.auth.dto.*;
import com.doconnect.auth.service.QuestionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/questions")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class QuestionController {
    private final QuestionService questionService;

    @PostMapping
    public ResponseEntity<ApiResponse<QuestionDto>> createQuestion(@Valid @RequestBody QuestionRequest req, Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Question submitted for review", questionService.createQuestion(req, auth.getName())));
    }

    @GetMapping("/approved")
    public ResponseEntity<ApiResponse<List<QuestionDto>>> getApproved() {
        return ResponseEntity.ok(ApiResponse.success(questionService.getApprovedQuestions()));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<QuestionDto>>> search(@RequestParam String keyword) {
        return ResponseEntity.ok(ApiResponse.success(questionService.searchQuestions(keyword)));
    }

    @GetMapping("/my")
    public ResponseEntity<ApiResponse<List<QuestionDto>>> getMyQuestions(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success(questionService.getMyQuestions(auth.getName())));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<QuestionDto>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(questionService.getQuestionById(id)));
    }

    @PostMapping("/{id}/answers")
    public ResponseEntity<ApiResponse<AnswerDto>> addAnswer(@PathVariable Long id, @Valid @RequestBody AnswerRequest req, Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Answer submitted for review", questionService.addAnswer(id, req, auth.getName())));
    }

    @PostMapping("/answers/{id}/like")
    public ResponseEntity<ApiResponse<AnswerDto>> likeAnswer(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(questionService.likeAnswer(id)));
    }

    @PostMapping("/answers/{id}/comments")
    public ResponseEntity<ApiResponse<CommentDto>> addComment(@PathVariable Long id, @RequestBody java.util.Map<String, String> body, Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success(questionService.addComment(id, body.get("content"), auth.getName())));
    }
}

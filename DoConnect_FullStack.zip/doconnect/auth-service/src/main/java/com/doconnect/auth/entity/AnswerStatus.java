package com.doconnect.auth.entity;
public enum AnswerStatus { PENDING, APPROVED, REJECTED }

package com.doconnect.auth.entity;
public enum QuestionStatus { PENDING, APPROVED, REJECTED }

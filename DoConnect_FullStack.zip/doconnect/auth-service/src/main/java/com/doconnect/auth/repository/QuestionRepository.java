package com.doconnect.auth.repository;

import com.doconnect.auth.entity.Question;
import com.doconnect.auth.entity.QuestionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface QuestionRepository extends JpaRepository<Question, Long> {
    List<Question> findByStatus(QuestionStatus status);
    List<Question> findByAuthorId(Long userId);
    @Query("SELECT q FROM Question q WHERE q.status = 'APPROVED' AND (LOWER(q.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(q.body) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(q.tags) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<Question> searchQuestions(@Param("keyword") String keyword);
    List<Question> findByStatusAndClosedFalseOrderByCreatedAtDesc(QuestionStatus status);
}

package com.doconnect.auth.dto;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class MessageDto {
    private Long id;
    private String content;
    private UserDto sender;
    private UserDto receiver;
    private boolean read;
    private LocalDateTime createdAt;
}

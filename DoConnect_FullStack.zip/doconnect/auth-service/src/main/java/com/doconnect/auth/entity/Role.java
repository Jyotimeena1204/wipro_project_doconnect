package com.doconnect.auth.entity;
public enum Role { USER, ADMIN }

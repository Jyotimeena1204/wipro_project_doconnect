package com.doconnect.auth.dto;
import lombok.*;

@Data @AllArgsConstructor @Builder
public class AuthResponse {
    private String token;
    private Long userId;
    private String username;
    private String email;
    private String role;
    private boolean active;
}

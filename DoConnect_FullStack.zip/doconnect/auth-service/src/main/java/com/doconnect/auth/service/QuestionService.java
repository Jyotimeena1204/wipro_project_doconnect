package com.doconnect.auth.service;

import com.doconnect.auth.dto.*;
import com.doconnect.auth.entity.*;
import com.doconnect.auth.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuestionService {
    private final QuestionRepository questionRepository;
    private final AnswerRepository answerRepository;
    private final CommentRepository commentRepository;
    private final UserRepository userRepository;
    private final NotificationRepository notificationRepository;
    private final UserService userService;

    public QuestionDto createQuestion(QuestionRequest req, String email) {
        User user = userRepository.findByEmail(email).orElseThrow();
        Question q = Question.builder()
                .title(req.getTitle()).body(req.getBody()).tags(req.getTags())
                .author(user).status(QuestionStatus.PENDING).build();
        q = questionRepository.save(q);

        // Notify admins
        userRepository.findAll().stream()
                .filter(u -> u.getRole() == Role.ADMIN)
                .forEach(admin -> {
                    Notification n = Notification.builder()
                            .recipient(admin).type("NEW_QUESTION")
                            .message("New question posted: " + req.getTitle())
                            .build();
                    notificationRepository.save(n);
                });

        return toDto(q, false);
    }

    public List<QuestionDto> getApprovedQuestions() {
        return questionRepository.findByStatusAndClosedFalseOrderByCreatedAtDesc(QuestionStatus.APPROVED)
                .stream().map(q -> toDto(q, false)).collect(Collectors.toList());
    }

    public List<QuestionDto> searchQuestions(String keyword) {
        return questionRepository.searchQuestions(keyword)
                .stream().map(q -> toDto(q, false)).collect(Collectors.toList());
    }

    public QuestionDto getQuestionById(Long id) {
        Question q = questionRepository.findById(id).orElseThrow();
        return toDto(q, true);
    }

    public List<QuestionDto> getMyQuestions(String email) {
        User user = userRepository.findByEmail(email).orElseThrow();
        return questionRepository.findByAuthorId(user.getId())
                .stream().map(q -> toDto(q, false)).collect(Collectors.toList());
    }

    public AnswerDto addAnswer(Long questionId, AnswerRequest req, String email) {
        User user = userRepository.findByEmail(email).orElseThrow();
        Question q = questionRepository.findById(questionId).orElseThrow();
        Answer a = Answer.builder().content(req.getContent()).question(q).author(user).build();
        a = answerRepository.save(a);

        // Notify admins
        userRepository.findAll().stream()
                .filter(u -> u.getRole() == Role.ADMIN)
                .forEach(admin -> {
                    Notification n = Notification.builder()
                            .recipient(admin).type("NEW_ANSWER")
                            .message("New answer posted on: " + q.getTitle())
                            .build();
                    notificationRepository.save(n);
                });

        return toAnswerDto(a, false);
    }

    public AnswerDto likeAnswer(Long answerId) {
        Answer a = answerRepository.findById(answerId).orElseThrow();
        a.setLikeCount(a.getLikeCount() + 1);
        return toAnswerDto(answerRepository.save(a), true);
    }

    public CommentDto addComment(Long answerId, String content, String email) {
        User user = userRepository.findByEmail(email).orElseThrow();
        Answer a = answerRepository.findById(answerId).orElseThrow();
        Comment c = Comment.builder().content(content).answer(a).author(user).build();
        c = commentRepository.save(c);
        return CommentDto.builder().id(c.getId()).content(c.getContent())
                .author(userService.toDto(user)).createdAt(c.getCreatedAt()).build();
    }

    public QuestionDto toDto(Question q, boolean includeAnswers) {
        QuestionDto.QuestionDtoBuilder builder = QuestionDto.builder()
                .id(q.getId()).title(q.getTitle()).body(q.getBody()).tags(q.getTags())
                .status(q.getStatus().name()).closed(q.isClosed())
                .author(userService.toDto(q.getAuthor()))
                .createdAt(q.getCreatedAt()).updatedAt(q.getUpdatedAt());
        if (includeAnswers && q.getAnswers() != null) {
            builder.answers(q.getAnswers().stream()
                    .filter(a -> a.getStatus() == AnswerStatus.APPROVED)
                    .map(a -> toAnswerDto(a, true)).collect(Collectors.toList()));
        }
        return builder.build();
    }

    public AnswerDto toAnswerDto(Answer a, boolean includeComments) {
        AnswerDto.AnswerDtoBuilder builder = AnswerDto.builder()
                .id(a.getId()).content(a.getContent()).status(a.getStatus().name())
                .likeCount(a.getLikeCount()).author(userService.toDto(a.getAuthor()))
                .createdAt(a.getCreatedAt());
        if (includeComments && a.getComments() != null) {
            builder.comments(a.getComments().stream()
                    .map(c -> CommentDto.builder().id(c.getId()).content(c.getContent())
                            .author(userService.toDto(c.getAuthor())).createdAt(c.getCreatedAt()).build())
                    .collect(Collectors.toList()));
        }
        return builder.build();
    }
}

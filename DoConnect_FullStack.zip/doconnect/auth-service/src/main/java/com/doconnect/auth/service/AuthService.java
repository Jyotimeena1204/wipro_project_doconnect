package com.doconnect.auth.service;

import com.doconnect.auth.dto.*;
import com.doconnect.auth.entity.*;
import com.doconnect.auth.repository.UserRepository;
import com.doconnect.auth.security.JwtUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    private final AuthenticationManager authenticationManager;

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail()))
            throw new RuntimeException("Email already in use");
        if (userRepository.existsByUsername(request.getUsername()))
            throw new RuntimeException("Username already taken");

        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .bio(request.getBio())
                .role(Role.USER)
                .active(true)
                .build();
        user = userRepository.save(user);
        String token = jwtUtils.generateJwtToken(user.getEmail(), user.getRole().name());
        return AuthResponse.builder()
                .token(token).userId(user.getId()).username(user.getUsername())
                .email(user.getEmail()).role(user.getRole().name()).active(user.isActive())
                .build();
    }

    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));
        if (!user.isActive()) throw new RuntimeException("Account is deactivated");
        String token = jwtUtils.generateJwtToken(user.getEmail(), user.getRole().name());
        return AuthResponse.builder()
                .token(token).userId(user.getId()).username(user.getUsername())
                .email(user.getEmail()).role(user.getRole().name()).active(user.isActive())
                .build();
    }
}

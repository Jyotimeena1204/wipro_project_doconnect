package com.doconnect.auth.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class QuestionRequest {
    @NotBlank private String title;
    @NotBlank private String body;
    private String tags;
}

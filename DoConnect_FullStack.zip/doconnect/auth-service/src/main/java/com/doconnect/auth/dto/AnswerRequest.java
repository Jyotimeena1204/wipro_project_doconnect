package com.doconnect.auth.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class AnswerRequest {
    @NotBlank private String content;
}

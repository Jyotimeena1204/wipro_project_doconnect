package com.doconnect.auth.repository;

import com.doconnect.auth.entity.Answer;
import com.doconnect.auth.entity.AnswerStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AnswerRepository extends JpaRepository<Answer, Long> {
    List<Answer> findByQuestionIdAndStatus(Long questionId, AnswerStatus status);
    List<Answer> findByAuthorId(Long userId);
    List<Answer> findByStatus(AnswerStatus status);
}

package com.doconnect.auth.dto;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CommentDto {
    private Long id;
    private String content;
    private UserDto author;
    private LocalDateTime createdAt;
}

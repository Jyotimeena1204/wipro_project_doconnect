package com.doconnect.auth.repository;

import com.doconnect.auth.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByRecipientIdOrderByCreatedAtDesc(Long userId);
    List<Notification> findByRecipientIdAndReadFalse(Long userId);
    long countByRecipientIdAndReadFalse(Long userId);
}

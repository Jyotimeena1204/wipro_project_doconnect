package com.doconnect.auth.dto;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AnswerDto {
    private Long id;
    private String content;
    private String status;
    private int likeCount;
    private UserDto author;
    private List<CommentDto> comments;
    private LocalDateTime createdAt;
}

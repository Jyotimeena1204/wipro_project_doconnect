package com.doconnect.auth.dto;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class QuestionDto {
    private Long id;
    private String title;
    private String body;
    private String tags;
    private String status;
    private boolean closed;
    private UserDto author;
    private List<AnswerDto> answers;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

package com.doconnect.auth.dto;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class UserDto {
    private Long id;
    private String username;
    private String email;
    private String role;
    private boolean active;
    private String bio;
    private String profilePicture;
    private LocalDateTime createdAt;
}

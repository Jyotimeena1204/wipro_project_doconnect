package com.doconnect.auth.service;

import com.doconnect.auth.dto.UserDto;
import com.doconnect.auth.entity.User;
import com.doconnect.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    public UserDto getUserById(Long id) {
        return toDto(userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found")));
    }

    public UserDto getUserByEmail(String email) {
        return toDto(userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found")));
    }

    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    public UserDto updateProfile(Long id, UserDto dto) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        if (dto.getBio() != null) user.setBio(dto.getBio());
        if (dto.getProfilePicture() != null) user.setProfilePicture(dto.getProfilePicture());
        return toDto(userRepository.save(user));
    }

    public UserDto toDto(User user) {
        return UserDto.builder()
                .id(user.getId()).username(user.getUsername()).email(user.getEmail())
                .role(user.getRole().name()).active(user.isActive()).bio(user.getBio())
                .profilePicture(user.getProfilePicture()).createdAt(user.getCreatedAt())
                .build();
    }
}

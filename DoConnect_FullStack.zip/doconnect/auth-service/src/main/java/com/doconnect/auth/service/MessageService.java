package com.doconnect.auth.service;

import com.doconnect.auth.dto.MessageDto;
import com.doconnect.auth.entity.*;
import com.doconnect.auth.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MessageService {
    private final MessageRepository messageRepository;
    private final UserRepository userRepository;
    private final UserService userService;

    public MessageDto sendMessage(Long receiverId, String content, String senderEmail) {
        User sender = userRepository.findByEmail(senderEmail).orElseThrow();
        User receiver = userRepository.findById(receiverId).orElseThrow();
        Message m = Message.builder().sender(sender).receiver(receiver).content(content).build();
        m = messageRepository.save(m);
        return toDto(m);
    }

    public List<MessageDto> getConversation(Long userId1, Long userId2) {
        return messageRepository.findConversation(userId1, userId2)
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    private MessageDto toDto(Message m) {
        return MessageDto.builder().id(m.getId()).content(m.getContent())
                .sender(userService.toDto(m.getSender())).receiver(userService.toDto(m.getReceiver()))
                .read(m.isRead()).createdAt(m.getCreatedAt()).build();
    }
}

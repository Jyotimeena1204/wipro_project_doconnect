package com.doconnect.auth.controller;

import com.doconnect.auth.dto.*;
import com.doconnect.auth.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/messages")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class MessageController {
    private final MessageService messageService;
    private final UserService userService;

    @PostMapping("/{receiverId}")
    public ResponseEntity<ApiResponse<MessageDto>> send(@PathVariable Long receiverId, @RequestBody Map<String, String> body, Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success(messageService.sendMessage(receiverId, body.get("content"), auth.getName())));
    }

    @GetMapping("/conversation/{userId}")
    public ResponseEntity<ApiResponse<List<MessageDto>>> getConversation(@PathVariable Long userId, Authentication auth) {
        UserDto me = userService.getUserByEmail(auth.getName());
        return ResponseEntity.ok(ApiResponse.success(messageService.getConversation(me.getId(), userId)));
    }
}

package com.doconnect.auth.repository;

import com.doconnect.auth.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByAnswerIdOrderByCreatedAtAsc(Long answerId);
}
